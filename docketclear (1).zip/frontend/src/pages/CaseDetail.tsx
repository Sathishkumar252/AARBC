import { useParams } from 'react-router-dom'
import { useQuery, useMutation } from 'react-query'
import axios from 'axios'
import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { AlertTriangle, Calendar, CheckCircle, FileText, Gavel } from 'lucide-react'

export default function CaseDetail() {
  const { id } = useParams<{ id: string }>()
  const [reviewNotes, setReviewNotes] = useState('')

  const { data: caseData, refetch } = useQuery(['case', id], () =>
    axios.get(`/cases/${id}`).then((r) => r.data)
  )

  const analyzeMutation = useMutation(() => axios.post(`/cases/${id}/analyze`), {
    onSuccess: () => {
      toast.success('AI analysis complete')
      refetch()
    },
  })

  const reviewMutation = useMutation(
    (action: string) => axios.put(`/cases/${id}`, { review_action: action, review_notes: reviewNotes, human_reviewed: true }),
    { onSuccess: () => { toast.success('Review submitted'); refetch() } }
  )

  if (!caseData) return <div className="p-8">Loading...</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Case {caseData.cnr_number}</h1>
          <p className="text-gray-500 mt-1">{caseData.case_type} | Filed: {caseData.filing_date}</p>
        </div>
        <button
          onClick={() => analyzeMutation.mutate()}
          disabled={analyzeMutation.isLoading}
          className="btn-primary flex items-center gap-2"
        >
          <FileText className="w-4 h-4" />
          {analyzeMutation.isLoading ? 'Analyzing...' : 'Run AI Analysis'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Gavel className="w-5 h-5 text-judicial-600" /> Case Information
            </h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><span className="text-gray-500">Petitioner:</span> <span className="font-medium">{caseData.petitioner}</span></div>
              <div><span className="text-gray-500">Respondent:</span> <span className="font-medium">{caseData.respondent}</span></div>
              <div><span className="text-gray-500">Act/Section:</span> <span className="font-medium">{caseData.act_section || 'N/A'}</span></div>
              <div><span className="text-gray-500">Custody:</span> <span className="font-medium capitalize">{caseData.custody_status}</span></div>
              <div><span className="text-gray-500">Adjournments:</span> <span className="font-medium">{caseData.adjournment_count}</span></div>
              <div><span className="text-gray-500">Days Pending:</span> <span className="font-medium">{caseData.days_since_filing}</span></div>
            </div>
          </div>

          {caseData.ai_summary && (
            <div className="card border-l-4 border-judicial-500">
              <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
                <FileText className="w-5 h-5 text-judicial-600" /> AI Case Summary
              </h2>
              <p className="text-gray-700 leading-relaxed">{caseData.ai_summary}</p>
            </div>
          )}

          {caseData.ai_recommendation && (
            <div className="card border-l-4 border-amber-500">
              <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" /> AI Recommendation
              </h2>
              <p className="text-gray-700 leading-relaxed">{caseData.ai_recommendation}</p>
            </div>
          )}

          {caseData.ai_risk_flags?.length > 0 && (
            <div className="card bg-red-50 border border-red-200">
              <h2 className="text-lg font-semibold mb-3 text-red-800 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" /> Risk Flags
              </h2>
              <div className="flex flex-wrap gap-2">
                {caseData.ai_risk_flags.map((flag: string) => (
                  <span key={flag} className="badge-urgent">{flag.replace(/_/g, ' ')}</span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" /> Human Review
            </h2>
            {!caseData.human_reviewed ? (
              <div className="space-y-4">
                <textarea
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Add review notes..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-judicial-500"
                  rows={3}
                />
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => reviewMutation.mutate('approve')} className="btn-primary text-sm py-2">Approve</button>
                  <button onClick={() => reviewMutation.mutate('edit')} className="btn-secondary text-sm py-2">Edit</button>
                  <button onClick={() => reviewMutation.mutate('reject')} className="btn-secondary text-sm py-2 text-red-600 border-red-300">Reject</button>
                  <button onClick={() => reviewMutation.mutate('override')} className="btn-secondary text-sm py-2">Override</button>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                <p className="font-medium text-green-800">Reviewed: {caseData.review_action}</p>
                {caseData.review_notes && <p className="text-sm text-gray-600 mt-2">{caseData.review_notes}</p>}
              </div>
            )}
          </div>

          <div className="card">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-judicial-600" /> Suggested Dates
            </h2>
            {caseData.ai_suggested_dates?.length > 0 ? (
              <ul className="space-y-2">
                {caseData.ai_suggested_dates.map((d: string, i: number) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-700 p-2 bg-gray-50 rounded">
                    <Calendar className="w-4 h-4 text-judicial-500" /> {d}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500">No dates suggested yet. Run AI analysis.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
