import { useQuery, useMutation } from 'react-query'
import axios from 'axios'
import { AlertTriangle, CheckCircle } from 'lucide-react'
import { toast } from 'react-hot-toast'

interface Alert {
  id: number
  alert_type: string
  severity: string
  title: string
  message: string
  is_read: boolean
  created_at: string
}

export default function Alerts() {
  const { data: alerts, refetch } = useQuery<Alert[]>('alerts', () =>
    axios.get('/alerts/').then((r) => r.data)
  )

  const ack = useMutation((id: number) => axios.post(`/alerts/${id}/acknowledge`), {
    onSuccess: () => { toast.success('Acknowledged'); refetch() }
  })

  const getSeverityColor = (s: string) => {
    if (s === 'critical') return 'border-red-500 bg-red-50'
    if (s === 'high') return 'border-orange-500 bg-orange-50'
    if (s === 'medium') return 'border-yellow-500 bg-yellow-50'
    return 'border-green-500 bg-green-50'
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Alerts</h1>
      <div className="space-y-3">
        {alerts?.map((a) => (
          <div key={a.id} className={`card border-l-4 ${getSeverityColor(a.severity)} ${a.is_read ? 'opacity-60' : ''}`}>
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <AlertTriangle className={`w-5 h-5 ${a.severity === 'critical' ? 'text-red-600' : 'text-amber-600'}`} />
                <div>
                  <h3 className="font-semibold text-gray-900">{a.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{a.message}</p>
                  <p className="text-xs text-gray-400 mt-2">{new Date(a.created_at).toLocaleString()}</p>
                </div>
              </div>
              {!a.is_read && (
                <button onClick={() => ack.mutate(a.id)} className="btn-secondary text-xs py-1 px-3">
                  <CheckCircle className="w-3 h-3 inline mr-1" /> Acknowledge
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
