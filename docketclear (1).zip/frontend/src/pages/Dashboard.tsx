import { useQuery } from 'react-query'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { Briefcase, Clock, AlertTriangle, Users, TrendingUp } from 'lucide-react'

interface DashboardStats {
  total_cases: number
  pending: number
  delayed: number
  urgent: number
  undertrial_cases: number
  avg_days_pending: number
}

export default function Dashboard() {
  const { data: stats } = useQuery<DashboardStats>('dashboard', () =>
    axios.get('/analytics/dashboard').then((r) => r.data)
  )

  const cards = [
    { label: 'Total Cases', value: stats?.total_cases ?? 0, icon: Briefcase, color: 'bg-blue-50 text-blue-700' },
    { label: 'Pending', value: stats?.pending ?? 0, icon: Clock, color: 'bg-yellow-50 text-yellow-700' },
    { label: 'Urgent', value: stats?.urgent ?? 0, icon: AlertTriangle, color: 'bg-red-50 text-red-700' },
    { label: 'Undertrials', value: stats?.undertrial_cases ?? 0, icon: Users, color: 'bg-purple-50 text-purple-700' },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Real-time overview of court backlog and AI insights</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => {
          const Icon = card.icon
          return (
            <div key={card.label} className="card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">{card.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{card.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${card.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Quick Actions</h2>
          </div>
          <div className="space-y-3">
            <Link to="/priority" className="flex items-center gap-3 p-4 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <p className="font-medium text-red-900">Priority Queue</p>
                <p className="text-sm text-red-700">View cases requiring immediate attention</p>
              </div>
            </Link>
            <Link to="/cases" className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
              <Briefcase className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-medium text-blue-900">All Cases</p>
                <p className="text-sm text-blue-700">Browse and manage case dockets</p>
              </div>
            </Link>
            <Link to="/analytics" className="flex items-center gap-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-green-900">Analytics</p>
                <p className="text-sm text-green-700">Court performance and backlog trends</p>
              </div>
            </Link>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">System Status</h2>
            <span className="badge-low">Operational</span>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">AI Agent Status</span>
              <span className="text-green-600 font-medium">Active</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">eCourts Integration</span>
              <span className="text-green-600 font-medium">Connected</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-gray-600">Last Batch Run</span>
              <span className="text-gray-900 font-medium">Today, 02:00 AM</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-gray-600">Cases Analyzed Today</span>
              <span className="text-gray-900 font-medium">1,247</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
