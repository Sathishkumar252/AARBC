import { useState } from 'react'
import { useQuery } from 'react-query'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { Search, Filter, ChevronRight } from 'lucide-react'

interface CaseItem {
  id: number
  cnr_number: string
  case_type: string
  status: string
  petitioner: string
  respondent: string
  priority_score: number
  days_since_filing: number
  next_hearing_date: string | null
  custody_status: string
  human_reviewed: boolean
}

export default function Cases() {
  const [search, setSearch] = useState('')
  const { data: cases, isLoading } = useQuery<CaseItem[]>('cases', () =>
    axios.get('/cases/').then((r) => r.data)
  )

  const filtered = cases?.filter((c) =>
    c.cnr_number.toLowerCase().includes(search.toLowerCase()) ||
    c.petitioner.toLowerCase().includes(search.toLowerCase()) ||
    c.respondent.toLowerCase().includes(search.toLowerCase())
  )

  const getPriorityBadge = (score: number) => {
    if (score >= 80) return <span className="badge-urgent">Urgent</span>
    if (score >= 60) return <span className="badge-high">High</span>
    if (score >= 40) return <span className="badge-medium">Medium</span>
    return <span className="badge-low">Low</span>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Cases</h1>
          <p className="text-gray-500 mt-1">Manage and review court cases</p>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by CNR, party name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-judicial-500"
          />
        </div>
        <button className="btn-secondary flex items-center gap-2">
          <Filter className="w-4 h-4" /> Filter
        </button>
      </div>

      <div className="card overflow-hidden p-0">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">CNR</th>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Parties</th>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Status</th>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Priority</th>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Pending</th>
              <th className="text-left px-6 py-3 text-xs font-semibold text-gray-500 uppercase">Reviewed</th>
              <th className="px-6 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {isLoading ? (
              <tr><td colSpan={7} className="px-6 py-8 text-center text-gray-500">Loading cases...</td></tr>
            ) : filtered?.length === 0 ? (
              <tr><td colSpan={7} className="px-6 py-8 text-center text-gray-500">No cases found</td></tr>
            ) : (
              filtered?.map((c) => (
                <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-judicial-700">{c.cnr_number}</td>
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <p className="font-medium text-gray-900">{c.petitioner}</p>
                      <p className="text-gray-500">vs {c.respondent}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="capitalize text-sm text-gray-700">{c.status}</span>
                  </td>
                  <td className="px-6 py-4">{getPriorityBadge(c.priority_score)}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{c.days_since_filing} days</td>
                  <td className="px-6 py-4">
                    {c.human_reviewed ? (
                      <span className="text-green-600 text-sm font-medium">✓ Reviewed</span>
                    ) : (
                      <span className="text-amber-600 text-sm font-medium">Pending</span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <Link to={`/cases/${c.id}`} className="text-judicial-600 hover:text-judicial-800">
                      <ChevronRight className="w-5 h-5" />
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
