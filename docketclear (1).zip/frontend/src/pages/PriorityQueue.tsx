import { useQuery } from 'react-query'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { AlertTriangle, ArrowUpRight } from 'lucide-react'

interface UrgentCase {
  id: number
  cnr_number: string
  case_type: string
  status: string
  petitioner: string
  respondent: string
  priority_score: number
  days_since_filing: number
  custody_status: string
}

export default function PriorityQueue() {
  const { data: cases } = useQuery<UrgentCase[]>('urgent-cases', () =>
    axios.get('/cases/priority/urgent?min_score=70').then((r) => r.data)
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Priority Queue</h1>
        <p className="text-gray-500 mt-1">Cases flagged by AI as urgent or approaching statutory limits</p>
      </div>

      <div className="space-y-4">
        {cases?.length === 0 && <div className="card text-center py-12 text-gray-500">No urgent cases found</div>}
        {cases?.map((c) => (
          <div key={c.id} className="card border-l-4 border-red-500 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h3 className="text-lg font-semibold text-gray-900">{c.cnr_number}</h3>
                  <span className="badge-urgent">Score: {c.priority_score.toFixed(1)}</span>
                  {c.custody_status === 'undertrial' && <span className="badge-high">Undertrial</span>}
                </div>
                <p className="text-gray-600">{c.petitioner} <span className="text-gray-400">vs</span> {c.respondent}</p>
                <div className="flex gap-4 text-sm text-gray-500">
                  <span>Type: {c.case_type}</span>
                  <span>Pending: {c.days_since_filing} days</span>
                  <span>Status: {c.status}</span>
                </div>
              </div>
              <Link to={`/cases/${c.id}`} className="btn-secondary flex items-center gap-1 text-sm">
                Review <ArrowUpRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
