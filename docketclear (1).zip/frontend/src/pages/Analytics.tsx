import { useQuery } from 'react-query'
import axios from 'axios'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'

export default function Analytics() {
  const { data: trend } = useQuery('trend', () => axios.get('/analytics/backlog-trend').then((r) => r.data))
  const { data: perf } = useQuery('perf', () => axios.get('/analytics/court-performance').then((r) => r.data))

  const trendData = trend?.months.map((m: string, i: number) => ({
    month: m, filed: trend.filed[i], disposed: trend.disposed[i], backlog: trend.backlog[i]
  }))

  const perfData = perf?.courts.map((c: string, i: number) => ({
    court: c, clearance: perf.clearance_rate[i], pending: perf.pending_cases[i]
  }))

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Analytics</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Backlog Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="filed" stroke="#0ea5e9" name="Filed" />
              <Line type="monotone" dataKey="disposed" stroke="#22c55e" name="Disposed" />
              <Line type="monotone" dataKey="backlog" stroke="#ef4444" name="Backlog" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Court Performance</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={perfData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="court" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="clearance" fill="#0ea5e9" name="Clearance %" />
              <Bar dataKey="pending" fill="#f59e0b" name="Pending Cases" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
