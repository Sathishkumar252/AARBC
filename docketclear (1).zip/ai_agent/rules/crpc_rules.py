"""
CrPC / BNSS Legal Rules Engine
==============================
Codified statutory rules for automated compliance checking.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class StatutoryRule:
    code: str
    section: str
    description: str
    limit_days: int
    applicable_to: List[str]
    action_on_breach: str


CRPC_RULES = {
    "s167": StatutoryRule(
        code="CrPC",
        section="167",
        description="Maximum detention for investigation",
        limit_days=90,
        applicable_to=["criminal", "sessions"],
        action_on_breach="Mandatory release on bail",
    ),
    "s309": StatutoryRule(
        code="CrPC",
        section="309",
        description="Power to postpone or adjourn proceedings",
        limit_days=0,  # Discretionary but with reason
        applicable_to=["all"],
        action_on_breach="Mandate continuous trial",
    ),
    "s437": StatutoryRule(
        code="CrPC",
        section="437",
        description="Bail in non-bailable offences",
        limit_days=0,
        applicable_to=["criminal"],
        action_on_breach="Review bail eligibility",
    ),
    "s438": StatutoryRule(
        code="CrPC",
        section="438",
        description="Anticipatory bail",
        limit_days=0,
        applicable_to=["criminal"],
        action_on_breach="N/A",
    ),
}

BNSS_RULES = {
    "s187": StatutoryRule(
        code="BNSS",
        section="187",
        description="Procedure when investigation cannot be completed",
        limit_days=90,
        applicable_to=["criminal", "sessions"],
        action_on_breach="Release accused on bail",
    ),
    "s258": StatutoryRule(
        code="BNSS",
        section="258",
        description="Power to postpone or adjourn proceedings",
        limit_days=0,
        applicable_to=["all"],
        action_on_breach="Mandate continuous trial",
    ),
}


class LegalRulesEngine:
    """Engine to check cases against codified legal rules."""

    def __init__(self, use_bnss: bool = True):
        self.rules = {**CRPC_RULES, **BNSS_RULES} if use_bnss else CRPC_RULES

    def check_detention_limit(self, days_in_detention: int, case_type: str = "criminal") -> Dict:
        rule = self.rules.get("s187") or self.rules.get("s167")
        if not rule:
            return {"compliant": True, "message": "No rule found"}

        breach = days_in_detention > rule.limit_days
        return {
            "rule": f"{rule.code} Section {rule.section}",
            "limit_days": rule.limit_days,
            "actual_days": days_in_detention,
            "breach": breach,
            "action": rule.action_on_breach if breach else "Compliant",
            "severity": "critical" if breach else "low",
        }

    def check_adjournment_rules(self, adjournment_count: int, reasons: List[str]) -> Dict:
        # Section 309 CrPC / 258 BNSS - adjournments must be justified
        excessive = adjournment_count > 5
        return {
            "rule": "CrPC 309 / BNSS 258",
            "count": adjournment_count,
            "excessive": excessive,
            "recommendation": "Mandate continuous trial" if excessive else "Acceptable",
            "severity": "high" if excessive else "low",
        }

    def get_all_applicable_rules(self, case_type: str, custody_status: str) -> List[Dict]:
        """Get all rules applicable to a case."""
        applicable = []
        for key, rule in self.rules.items():
            if "all" in rule.applicable_to or case_type in rule.applicable_to:
                applicable.append({
                    "rule_key": key,
                    "code": rule.code,
                    "section": rule.section,
                    "description": rule.description,
                    "limit_days": rule.limit_days,
                    "action_on_breach": rule.action_on_breach,
                })
        return applicable
