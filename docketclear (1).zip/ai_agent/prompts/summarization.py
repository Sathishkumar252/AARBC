"""LLM Prompts for DocketClear"""

CASE_SUMMARY_PROMPT = """
You are DocketClear, an AI assistant for Indian courts. Generate a concise case summary for judicial review.

Case Details:
- CNR Number: {cnr_number}
- Case Type: {case_type}
- Filing Date: {filing_date}
- Days Pending: {days_pending}
- Petitioner: {petitioner}
- Respondent: {respondent}
- Custody Status: {custody_status}
- Days in Detention: {days_in_detention}
- Adjournments: {adjournment_count}
- Last Hearing: {last_hearing}
- Act/Section: {act_section}
- Subject: {subject}

Generate a 3-4 sentence summary highlighting:
1. Current status and pendency
2. Any custody/detention concerns
3. Recommended next steps
4. Statutory compliance issues if any

Summary (for judicial eyes only):
"""

SCHEDULING_PROMPT = """
Recommend hearing dates for the following case considering court workload and urgency.

Case: {cnr_number}
Priority Score: {priority_score}
Current Status: {status}
Suggested window: {suggested_window} days

Recommend {num_dates} dates with brief justification for each.
Output as JSON: {{"dates": ["YYYY-MM-DD"], "reasoning": "..."}}
"""

RISK_ASSESSMENT_PROMPT = """
Assess legal risks for this undertrial case:

CNR: {cnr_number}
Offence: {act_section}
Detention: {days_in_detention} days
Statutory Limit: {statutory_limit} days
Pending: {days_pending} days
Previous bail applications: {bail_history}

Identify:
1. Risk of statutory limit breach
2. Bail eligibility under CrPC 437/439
3. Any constitutional concerns (Article 21)
4. Recommended immediate actions

Output structured JSON.
"""
