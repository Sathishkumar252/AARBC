"""Case Pydantic schemas"""
from datetime import date, datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from app.models.case import CaseStatus, CaseType, CustodyStatus


class HearingOut(BaseModel):
    id: int
    hearing_date: date
    purpose: Optional[str]
    notes: Optional[str]
    outcome: Optional[str]
    next_date: Optional[date]
    reason_for_adjournment: Optional[str]

    class Config:
        from_attributes = True


class DocumentOut(BaseModel):
    id: int
    filename: str
    original_filename: str
    file_type: str
    file_size: int
    ocr_text: Optional[str]
    ocr_confidence: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True


class AlertOut(BaseModel):
    id: int
    alert_type: str
    severity: str
    title: str
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class CaseBase(BaseModel):
    cnr_number: str
    filing_number: str
    filing_date: date
    case_type: CaseType
    petitioner: str
    respondent: str
    advocate_petitioner: Optional[str] = None
    advocate_respondent: Optional[str] = None
    court_id: int
    judge_id: Optional[int] = None
    subject: Optional[str] = None
    act_section: Optional[str] = None
    custody_status: CustodyStatus = CustodyStatus.NA
    arrest_date: Optional[date] = None
    detention_start_date: Optional[date] = None


class CaseCreate(CaseBase):
    pass


class CaseUpdate(BaseModel):
    status: Optional[CaseStatus] = None
    next_hearing_date: Optional[date] = None
    custody_status: Optional[CustodyStatus] = None
    human_reviewed: Optional[bool] = None
    review_action: Optional[str] = None
    review_notes: Optional[str] = None


class CaseOut(CaseBase):
    id: int
    status: CaseStatus
    adjournment_count: int
    last_hearing_date: Optional[date]
    next_hearing_date: Optional[date]
    days_since_filing: int
    days_in_detention: int
    priority_score: float
    ai_summary: Optional[str]
    ai_recommendation: Optional[str]
    ai_suggested_dates: List[date] = []
    ai_risk_flags: List[str] = []
    human_reviewed: bool
    review_action: Optional[str]
    review_notes: Optional[str]
    created_at: datetime
    updated_at: datetime
    hearings: List[HearingOut] = []
    documents: List[DocumentOut] = []
    alerts: List[AlertOut] = []

    class Config:
        from_attributes = True


class CaseListItem(BaseModel):
    id: int
    cnr_number: str
    case_type: CaseType
    status: CaseStatus
    petitioner: str
    respondent: str
    priority_score: float
    days_since_filing: int
    next_hearing_date: Optional[date]
    custody_status: CustodyStatus
    human_reviewed: bool

    class Config:
        from_attributes = True


class CasePriorityFilter(BaseModel):
    min_priority: Optional[float] = Field(0, ge=0, le=100)
    status: Optional[CaseStatus] = None
    custody_status: Optional[CustodyStatus] = None
    court_id: Optional[int] = None
    days_pending_min: Optional[int] = None
    statutory_limit_approaching: Optional[bool] = None
