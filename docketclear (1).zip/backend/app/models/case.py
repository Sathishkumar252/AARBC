"""Case / Docket models"""
import enum
from datetime import datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    Float,
)
from sqlalchemy.orm import relationship

from app.models.base import Base


class CaseStatus(str, enum.Enum):
    PENDING = "pending"
    ACTIVE = "active"
    ADJOURNED = "adjourned"
    DISPOSED = "disposed"
    CLOSED = "closed"
    DELAYED = "delayed"
    URGENT = "urgent"


class CaseType(str, enum.Enum):
    CIVIL = "civil"
    CRIMINAL = "criminal"
    FAMILY = "family"
    MOTOR_ACCIDENT = "motor_accident"
    LAND_DISPUTE = "land_dispute"
    OTHER = "other"


class CustodyStatus(str, enum.Enum):
    UNDERTRIAL = "undertrial"
    BAIL = "on_bail"
    JUDICIAL_CUSTODY = "judicial_custody"
    POLICE_CUSTODY = "police_custody"
    RELEASED = "released"
    NA = "na"


class Case(Base):
    __tablename__ = "cases"

    id = Column(Integer, primary_key=True, index=True)
    cnr_number = Column(String(50), unique=True, index=True, nullable=False)  # Case Number Record
    filing_number = Column(String(100), nullable=False)
    filing_date = Column(Date, nullable=False)
    case_type = Column(Enum(CaseType), default=CaseType.OTHER)
    status = Column(Enum(CaseStatus), default=CaseStatus.PENDING)

    # Parties
    petitioner = Column(String(500), nullable=False)
    respondent = Column(String(500), nullable=False)
    advocate_petitioner = Column(String(255), nullable=True)
    advocate_respondent = Column(String(255), nullable=True)

    # Court details
    court_id = Column(Integer, ForeignKey("courts.id"), nullable=False)
    judge_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    # Case metadata
    subject = Column(Text, nullable=True)
    act_section = Column(String(500), nullable=True)  # e.g., "IPC 302, 34"
    value_in_dispute = Column(Float, nullable=True)

    # Custody & detention tracking
    custody_status = Column(Enum(CustodyStatus), default=CustodyStatus.NA)
    arrest_date = Column(Date, nullable=True)
    detention_start_date = Column(Date, nullable=True)
    statutory_limit_days = Column(Integer, default=90)  # CrPC/BNSS limit

    # Backlog metrics
    adjournment_count = Column(Integer, default=0)
    last_hearing_date = Column(Date, nullable=True)
    next_hearing_date = Column(Date, nullable=True)
    days_since_filing = Column(Integer, default=0)
    days_in_detention = Column(Integer, default=0)
    priority_score = Column(Float, default=0.0)  # AI-calculated 0-100

    # AI outputs
    ai_summary = Column(Text, nullable=True)
    ai_recommendation = Column(Text, nullable=True)
    ai_suggested_dates = Column(JSON, default=list)
    ai_risk_flags = Column(JSON, default=list)

    # Human review
    human_reviewed = Column(Boolean, default=False)
    reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    review_action = Column(String(50), nullable=True)  # approve, edit, reject, override
    review_notes = Column(Text, nullable=True)

    # Source
    source_system = Column(String(50), default="manual")  # ecourts, njdg, manual
    raw_data = Column(JSON, default=dict)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    court = relationship("Court", back_populates="cases")
    hearings = relationship("Hearing", back_populates="case", cascade="all, delete-orphan")
    documents = relationship("Document", back_populates="case", cascade="all, delete-orphan")
    alerts = relationship("Alert", back_populates="case", cascade="all, delete-orphan")
