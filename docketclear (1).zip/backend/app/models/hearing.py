"""Hearing / Proceeding model"""
from datetime import datetime

from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.models.base import Base


class Hearing(Base):
    __tablename__ = "hearings"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id"), nullable=False)
    hearing_date = Column(Date, nullable=False)
    purpose = Column(String(255), nullable=True)  # arguments, evidence, judgment
    notes = Column(Text, nullable=True)
    outcome = Column(String(255), nullable=True)  # adjourned, disposed, reserved
    next_date = Column(Date, nullable=True)
    reason_for_adjournment = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    case = relationship("Case", back_populates="hearings")
