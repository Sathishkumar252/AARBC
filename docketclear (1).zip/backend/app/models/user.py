"""User model with Role-Based Access Control"""
import enum
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Enum, Integer, String, Text

from app.models.base import Base


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    JUDGE = "judge"
    CLERK = "clerk"
    REGISTRAR = "registrar"
    VIEWER = "viewer"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=False)
    role = Column(Enum(UserRole), default=UserRole.CLERK, nullable=False)
    court_id = Column(Integer, nullable=True)  # Foreign key to courts
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
