"""Application configuration using Pydantic Settings"""
from typing import List

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App
    APP_NAME: str = "DocketClear"
    DEBUG: bool = False
    SECRET_KEY: str = "super-secret-judicial-key-change-in-production"

    # Database
    DATABASE_URL: str = "postgresql://postgres:postgres@db:5432/docketclear"

    # Redis
    REDIS_URL: str = "redis://redis:6379/0"

    # MinIO / S3
    MINIO_ENDPOINT: str = "minio:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_BUCKET: str = "docketclear-docs"

    # OpenAI / LLM
    OPENAI_API_KEY: str = ""
    LLM_MODEL: str = "gpt-4-turbo-preview"
    LLM_TEMPERATURE: float = 0.2

    # eCourts / NJDG Integration
    ECOURTS_API_BASE: str = "https://ecourts.gov.in/ecourts_api"
    ECOURTS_API_KEY: str = ""
    NJDG_API_BASE: str = "https://njdg.ecourts.gov.in/njdg_api"

    # Auth
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    ALGORITHM: str = "HS256"

    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # Monitoring
    SENTRY_DSN: str = ""

    # Legal Rules
    CRPC_DETENTION_LIMIT_DAYS: int = 90  # General statutory limit
    BNSS_DETENTION_LIMIT_DAYS: int = 90

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
