"""Hearing scheduling recommendation service"""
from datetime import date, datetime, timedelta
from typing import List

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.case import Case
from app.models.hearing import Hearing


def recommend_hearing_dates(case: Case, db: Session, num_suggestions: int = 3) -> List[date]:
    """
    Recommend optimal hearing dates based on:
    - Court calendar availability
    - Case priority
    - Statutory deadlines
    - Avoiding clustering
    """
    suggestions = []
    today = date.today()

    # Base lead time depends on priority
    if case.priority_score >= 80:
        base_lead = 3  # days
    elif case.priority_score >= 60:
        base_lead = 7
    else:
        base_lead = 14

    # Check if approaching statutory limit
    if case.days_in_detention and case.days_in_detention > 60:
        base_lead = min(base_lead, 3)

    # Find available slots (simplified - in production would query court calendar)
    current = today + timedelta(days=base_lead)

    # Skip weekends
    while current.weekday() >= 5:
        current += timedelta(days=1)

    for _ in range(num_suggestions):
        # Check if court is already overloaded on this date
        case_count = db.query(func.count(Hearing.id)).filter(
            Hearing.hearing_date == current
        ).scalar()

        # If overloaded, push to next available day
        while case_count >= 20:  # Threshold
            current += timedelta(days=1)
            if current.weekday() >= 5:
                current += timedelta(days=1)
            case_count = db.query(func.count(Hearing.id)).filter(
                Hearing.hearing_date == current
            ).scalar()

        suggestions.append(current)
        current += timedelta(days=max(base_lead, 7))
        while current.weekday() >= 5:
            current += timedelta(days=1)

    return suggestions
