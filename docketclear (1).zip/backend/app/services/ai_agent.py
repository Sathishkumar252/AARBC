"""DocketClear AI Agent Core Service"""
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional

import structlog
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.alert import Alert, AlertSeverity, AlertType
from app.models.case import Case, CaseStatus, CustodyStatus

logger = structlog.get_logger()


class DocketClearAgent:
    """
    Autonomous AI Agent for court case backlog reduction.

    Capabilities:
    1. DETECT: Identify delayed and urgent cases
    2. DRAFT: Generate case summaries and recommendations
    3. SCHEDULE: Recommend hearing dates
    4. PRIORITIZE: Score cases by urgency
    """

    def __init__(self, db: Session):
        self.db = db
        self.statutory_limit_days = settings.CRPC_DETENTION_LIMIT_DAYS

    def analyze_case(self, case: Case) -> Dict[str, Any]:
        """Run full AI analysis on a case."""
        logger.info("agent_analyzing_case", cnr=case.cnr_number)

        # Calculate metrics
        self._update_case_metrics(case)

        # Priority scoring
        priority_score = self._calculate_priority_score(case)
        case.priority_score = priority_score

        # Risk detection
        risk_flags = self._detect_risks(case)
        case.ai_risk_flags = risk_flags

        # Generate summary
        summary = self._generate_summary(case)
        case.ai_summary = summary

        # Generate recommendation
        recommendation = self._generate_recommendation(case, risk_flags)
        case.ai_recommendation = recommendation

        # Create alerts for critical issues
        self._create_alerts(case, risk_flags)

        # Update status based on analysis
        if priority_score >= 80:
            case.status = CaseStatus.URGENT
        elif priority_score >= 60:
            case.status = CaseStatus.DELAYED

        self.db.commit()
        self.db.refresh(case)

        return {
            "priority_score": priority_score,
            "risk_flags": risk_flags,
            "summary": summary,
            "recommendation": recommendation,
            "days_pending": case.days_since_filing,
            "days_in_detention": case.days_in_detention,
        }

    def _update_case_metrics(self, case: Case) -> None:
        """Update derived metrics like days pending."""
        today = date.today()
        if case.filing_date:
            case.days_since_filing = (today - case.filing_date).days
        if case.detention_start_date:
            case.days_in_detention = (today - case.detention_start_date).days
        if case.arrest_date and not case.detention_start_date:
            case.days_in_detention = (today - case.arrest_date).days

    def _calculate_priority_score(self, case: Case) -> float:
        """
        Calculate priority score (0-100) based on multiple factors:
        - Days pending (exponential weight)
        - Custody status and detention duration
        - Adjournment count
        - Statutory limit proximity
        """
        score = 0.0

        # Factor 1: Days pending (max 30 points)
        if case.days_since_filing > 365:
            score += 30
        elif case.days_since_filing > 180:
            score += 20
        elif case.days_since_filing > 90:
            score += 10
        elif case.days_since_filing > 30:
            score += 5

        # Factor 2: Custody / Undertrial (max 40 points)
        if case.custody_status == CustodyStatus.UNDERTRIAL:
            score += 25
            # Additional weight if approaching statutory limit
            if case.days_in_detention > self.statutory_limit_days * 0.8:
                score += 15
            elif case.days_in_detention > self.statutory_limit_days * 0.5:
                score += 10
        elif case.custody_status == CustodyStatus.JUDICIAL_CUSTODY:
            score += 20
        elif case.custody_status == CustodyStatus.POLICE_CUSTODY:
            score += 30

        # Factor 3: Adjournments (max 15 points)
        if case.adjournment_count >= 10:
            score += 15
        elif case.adjournment_count >= 5:
            score += 10
        elif case.adjournment_count >= 3:
            score += 5

        # Factor 4: Case type urgency (max 10 points)
        if case.case_type.value == "criminal":
            score += 10
        elif case.case_type.value == "family":
            score += 5

        # Factor 5: Last hearing gap (max 5 points)
        if case.last_hearing_date:
            gap = (date.today() - case.last_hearing_date).days
            if gap > 90:
                score += 5
            elif gap > 60:
                score += 3

        return min(score, 100.0)

    def _detect_risks(self, case: Case) -> List[str]:
        """Detect risk flags for a case."""
        risks = []

        if case.custody_status == CustodyStatus.UNDERTRIAL:
            if case.days_in_detention > self.statutory_limit_days:
                risks.append("UNDETENTION_EXCEEDS_STATUTORY_LIMIT")
            elif case.days_in_detention > self.statutory_limit_days * 0.8:
                risks.append("STATUTORY_LIMIT_APPROACHING")

        if case.days_since_filing > 365:
            risks.append("CASE_PENDING_OVER_ONE_YEAR")
        elif case.days_since_filing > 180:
            risks.append("CASE_PENDING_OVER_SIX_MONTHS")

        if case.adjournment_count >= 10:
            risks.append("EXCESSIVE_ADJOURNMENTS")

        if case.last_hearing_date:
            gap = (date.today() - case.last_hearing_date).days
            if gap > 90:
                risks.append("NO_HEARING_IN_90_DAYS")

        if case.custody_status == CustodyStatus.UNDERTRIAL and case.days_in_detention > case.days_since_filing * 0.5:
            risks.append("HIGH_DETENTION_TO_PENDING_RATIO")

        return risks

    def _generate_summary(self, case: Case) -> str:
        """Generate a concise AI case summary."""
        parts = [
            f"Case {case.cnr_number} ({case.case_type.value.upper()})",
            f"Filed: {case.filing_date}. Pending for {case.days_since_filing} days.",
        ]

        if case.custody_status != CustodyStatus.NA:
            parts.append(f"Custody: {case.custody_status.value.replace('_', ' ').title()}. "
                        f"Duration: {case.days_in_detention} days.")

        parts.append(f"Adjournments: {case.adjournment_count}. "
                    f"Last hearing: {case.last_hearing_date or 'N/A'}.")

        if case.act_section:
            parts.append(f"Charges under: {case.act_section}.")

        if case.ai_risk_flags:
            parts.append(f"Risk flags: {', '.join(case.ai_risk_flags)}.")

        return " | ".join(parts)

    def _generate_recommendation(self, case: Case, risk_flags: List[str]) -> str:
        """Generate actionable recommendation."""
        recommendations = []

        if "UNDETENTION_EXCEEDS_STATUTORY_LIMIT" in risk_flags:
            recommendations.append(
                "URGENT: Undertrial detention exceeds statutory limit. "
                "Recommend immediate bail hearing or disposal."
            )

        if "STATUTORY_LIMIT_APPROACHING" in risk_flags:
            recommendations.append(
                f"Detention approaching {self.statutory_limit_days}-day limit. "
                "Schedule hearing within 7 days."
            )

        if "EXCESSIVE_ADJOURNMENTS" in risk_flags:
            recommendations.append(
                "High adjournment count. Review for continuous hearing or "
                "strict timeline under Section 309 CrPC."
            )

        if "NO_HEARING_IN_90_DAYS" in risk_flags:
            recommendations.append(
                "No hearing in 90+ days. Prioritize for next cause list."
            )

        if case.custody_status == CustodyStatus.UNDERTRIAL and case.days_in_detention > 60:
            recommendations.append(
                "Consider video conferencing for undertrial to reduce custody time."
            )

        if not recommendations:
            recommendations.append(
                "Case within normal parameters. Continue monitoring."
            )

        return " ".join(recommendations)

    def _create_alerts(self, case: Case, risk_flags: List[str]) -> None:
        """Create alerts for critical risk flags."""
        alert_configs = {
            "UNDETENTION_EXCEEDS_STATUTORY_LIMIT": (
                AlertType.UNDERTRIAL_OVERDETENTION,
                AlertSeverity.CRITICAL,
                "Undertrial exceeds statutory detention limit",
                f"Case {case.cnr_number}: Undertrial has been in detention for "
                f"{case.days_in_detention} days, exceeding the {self.statutory_limit_days}-day limit. "
                f"Immediate judicial intervention required."
            ),
            "STATUTORY_LIMIT_APPROACHING": (
                AlertType.STATUTORY_LIMIT,
                AlertSeverity.HIGH,
                "Statutory detention limit approaching",
                f"Case {case.cnr_number}: Detention at {case.days_in_detention} days. "
                f"Approaching {self.statutory_limit_days}-day statutory limit."
            ),
            "EXCESSIVE_ADJOURNMENTS": (
                AlertType.EXCESSIVE_ADJOURNMENT,
                AlertSeverity.MEDIUM,
                "Excessive adjournments detected",
                f"Case {case.cnr_number} has {case.adjournment_count} adjournments. "
                f"Consider mandating continuous trial."
            ),
            "NO_HEARING_IN_90_DAYS": (
                AlertType.LONG_PENDING,
                AlertSeverity.MEDIUM,
                "No hearing in 90+ days",
                f"Case {case.cnr_number} has had no hearing for over 90 days. "
                f"Recommend scheduling."
            ),
        }

        for flag in risk_flags:
            if flag in alert_configs:
                alert_type, severity, title, message = alert_configs[flag]
                # Check if alert already exists and unread
                existing = self.db.query(Alert).filter(
                    Alert.case_id == case.id,
                    Alert.alert_type == alert_type,
                    Alert.is_read == False
                ).first()
                if not existing:
                    alert = Alert(
                        case_id=case.id,
                        alert_type=alert_type,
                        severity=severity,
                        title=title,
                        message=message,
                    )
                    self.db.add(alert)
        self.db.commit()
