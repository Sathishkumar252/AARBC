"""OCR and document processing utilities"""
import io
from typing import Any, Dict

try:
    import pytesseract
    from PIL import Image
    TESSERACT_AVAILABLE = True
except ImportError:
    TESSERACT_AVAILABLE = False

try:
    from pdf2image import convert_from_bytes
    PDF2IMAGE_AVAILABLE = True
except ImportError:
    PDF2IMAGE_AVAILABLE = False


def extract_text_from_file(content: bytes, file_ext: str) -> Dict[str, Any]:
    """Extract text from uploaded documents using OCR."""
    text = ""
    confidence = 0

    file_ext = file_ext.lower().replace(".", "")

    if file_ext in ["jpg", "jpeg", "png", "tiff", "bmp"]:
        if TESSERACT_AVAILABLE:
            image = Image.open(io.BytesIO(content))
            text = pytesseract.image_to_string(image, lang="eng+hin")
            confidence = 85  # Estimated

    elif file_ext == "pdf":
        if PDF2IMAGE_AVAILABLE and TESSERACT_AVAILABLE:
            images = convert_from_bytes(content, first_page=1, last_page=3)
            texts = []
            for img in images:
                page_text = pytesseract.image_to_string(img, lang="eng+hin")
                texts.append(page_text)
            text = "\n".join(texts)
            confidence = 80
        else:
            text = "[PDF processing requires tesseract and poppler]"
            confidence = 0

    elif file_ext in ["doc", "docx"]:
        try:
            import docx
            doc = docx.Document(io.BytesIO(content))
            text = "\n".join([para.text for para in doc.paragraphs])
            confidence = 95
        except Exception:
            text = "[DOCX parsing failed]"

    return {
        "text": text[:10000],  # Limit storage
        "confidence": confidence,
        "word_count": len(text.split()),
    }
