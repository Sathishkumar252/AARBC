"""Celery background tasks"""
from celery import shared_task
import structlog

logger = structlog.get_logger()


@shared_task(bind=True, max_retries=3)
def analyze_case_async(self, case_id: int):
    """Run AI analysis on a case asynchronously."""
    try:
        from app.db.session import SessionLocal
        from app.models.case import Case
        from app.services.ai_agent import DocketClearAgent

        db = SessionLocal()
        case = db.query(Case).filter(Case.id == case_id).first()
        if not case:
            return {"error": "Case not found"}

        agent = DocketClearAgent(db)
        result = agent.analyze_case(case)
        db.close()

        logger.info("case_analysis_complete", case_id=case_id)
        return result
    except Exception as exc:
        logger.error("case_analysis_failed", case_id=case_id, error=str(exc))
        raise self.retry(exc=exc, countdown=60)


@shared_task
def batch_detect_delayed_cases():
    """Nightly batch job to detect delayed cases across all courts."""
    from app.db.session import SessionLocal
    from app.models.case import Case, CaseStatus
    from app.services.ai_agent import DocketClearAgent

    db = SessionLocal()
    cases = db.query(Case).filter(
        Case.status.in_([CaseStatus.PENDING, CaseStatus.ADJOURNED])
    ).all()

    agent = DocketClearAgent(db)
    processed = 0
    alerts = 0

    for case in cases:
        result = agent.analyze_case(case)
        processed += 1
        alerts += len(result.get("risk_flags", []))

    db.close()
    logger.info("batch_detection_complete", processed=processed, alerts=alerts)
    return {"processed": processed, "alerts_generated": alerts}


@shared_task
def process_ocr_document(document_id: int):
    """Process OCR for uploaded documents."""
    from app.db.session import SessionLocal
    from app.models.document import Document
    from app.utils.ocr import extract_text_from_file

    db = SessionLocal()
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        return {"error": "Document not found"}

    logger.info("ocr_processing_complete", document_id=document_id)
    db.close()
    return {"document_id": document_id, "status": "processed"}
