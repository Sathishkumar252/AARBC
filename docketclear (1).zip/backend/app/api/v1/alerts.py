"""Alert endpoints"""
from typing import Any, List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.v1.users import get_current_user
from app.db.session import get_db
from app.models.alert import Alert
from app.models.user import User

router = APIRouter()


@router.get("/")
def list_alerts(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    unread_only: bool = False,
    limit: int = 50,
) -> Any:
    query = db.query(Alert)
    if unread_only:
        query = query.filter(Alert.is_read == False)
    return query.order_by(Alert.created_at.desc()).limit(limit).all()


@router.post("/{alert_id}/acknowledge")
def acknowledge_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> Any:
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.is_read = True
    alert.acknowledged_by = current_user.id
    from datetime import datetime
    alert.acknowledged_at = datetime.utcnow()
    db.commit()
    return {"status": "acknowledged"}
