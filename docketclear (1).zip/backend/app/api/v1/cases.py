"""Case management and AI agent endpoints"""
from typing import Any, List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.api.v1.users import get_current_user, require_role
from app.db.session import get_db
from app.models.alert import Alert, AlertSeverity, AlertType
from app.models.case import Case, CaseStatus, CustodyStatus
from app.models.user import UserRole
from app.schemas.case import (
    CaseCreate,
    CaseListItem,
    CaseOut,
    CasePriorityFilter,
    CaseUpdate,
)
from app.services.ai_agent import DocketClearAgent
from app.services.scheduler import recommend_hearing_dates

router = APIRouter()


@router.get("/", response_model=List[CaseListItem])
def list_cases(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    status: CaseStatus = Query(None),
    court_id: int = Query(None),
    skip: int = 0,
    limit: int = 50,
    priority_sort: bool = Query(True),
) -> Any:
    query = db.query(Case)
    if status:
        query = query.filter(Case.status == status)
    if court_id:
        query = query.filter(Case.court_id == court_id)
    elif current_user.court_id and current_user.role != UserRole.ADMIN:
        query = query.filter(Case.court_id == current_user.court_id)
    if priority_sort:
        query = query.order_by(desc(Case.priority_score))
    return query.offset(skip).limit(limit).all()


@router.post("/", response_model=CaseOut)
def create_case(
    *,
    db: Session = Depends(get_db),
    case_in: CaseCreate,
    current_user = Depends(require_role(UserRole.CLERK, UserRole.REGISTRAR, UserRole.ADMIN)),
) -> Any:
    case = Case(**case_in.model_dump())
    db.add(case)
    db.commit()
    db.refresh(case)
    return case


@router.get("/{case_id}", response_model=CaseOut)
def get_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
) -> Any:
    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return case


@router.put("/{case_id}", response_model=CaseOut)
def update_case(
    case_id: int,
    case_in: CaseUpdate,
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.JUDGE, UserRole.CLERK, UserRole.REGISTRAR)),
) -> Any:
    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    for field, value in case_in.model_dump(exclude_unset=True).items():
        setattr(case, field, value)
    db.commit()
    db.refresh(case)
    return case


@router.post("/{case_id}/analyze")
def analyze_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.JUDGE, UserRole.REGISTRAR)),
) -> Any:
    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    agent = DocketClearAgent(db)
    result = agent.analyze_case(case)
    return {"case_id": case_id, "analysis": result}


@router.post("/{case_id}/schedule")
def schedule_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.JUDGE, UserRole.REGISTRAR, UserRole.CLERK)),
) -> Any:
    case = db.query(Case).filter(Case.id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    suggested_dates = recommend_hearing_dates(case, db)
    case.ai_suggested_dates = [d.isoformat() for d in suggested_dates]
    db.commit()
    return {"case_id": case_id, "suggested_dates": suggested_dates}


@router.get("/priority/urgent", response_model=List[CaseListItem])
def get_urgent_cases(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
    min_score: float = Query(70.0, ge=0, le=100),
    limit: int = Query(50),
) -> Any:
    query = db.query(Case).filter(Case.priority_score >= min_score)
    if current_user.court_id and current_user.role != UserRole.ADMIN:
        query = query.filter(Case.court_id == current_user.court_id)
    return query.order_by(desc(Case.priority_score)).limit(limit).all()


@router.post("/batch/detect-delayed")
def detect_delayed_cases(
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.REGISTRAR, UserRole.ADMIN)),
) -> Any:
    """Batch job: Run AI detection on all pending cases."""
    agent = DocketClearAgent(db)
    cases = db.query(Case).filter(Case.status.in_([CaseStatus.PENDING, CaseStatus.ADJOURNED])).all()
    results = []
    for case in cases:
        result = agent.analyze_case(case)
        results.append({"cnr": case.cnr_number, "priority": case.priority_score, "flags": result.get("risk_flags", [])})
    return {"processed": len(results), "results": results}
