"""Analytics and reporting endpoints"""
from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.api.v1.users import get_current_user, require_role
from app.db.session import get_db
from app.models.case import Case, CaseStatus, CustodyStatus
from app.models.user import UserRole

router = APIRouter()


@router.get("/dashboard")
def get_dashboard_stats(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user),
) -> Any:
    total_cases = db.query(Case).count()
    pending = db.query(Case).filter(Case.status == CaseStatus.PENDING).count()
    delayed = db.query(Case).filter(Case.status == CaseStatus.DELAYED).count()
    urgent = db.query(Case).filter(Case.status == CaseStatus.URGENT).count()
    undertrial = db.query(Case).filter(Case.custody_status == CustodyStatus.UNDERTRIAL).count()
    avg_days_pending = db.query(func.avg(Case.days_since_filing)).scalar() or 0

    return {
        "total_cases": total_cases,
        "pending": pending,
        "delayed": delayed,
        "urgent": urgent,
        "undertrial_cases": undertrial,
        "avg_days_pending": round(float(avg_days_pending), 1),
        "disposed_today": 0,  # Would filter by date
    }


@router.get("/backlog-trend")
def get_backlog_trend(
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.ADMIN, UserRole.REGISTRAR)),
) -> Any:
    # Simplified - in production would aggregate by month
    return {
        "months": ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        "filed": [1200, 1350, 1100, 1400, 1300, 1250],
        "disposed": [900, 1100, 1050, 1200, 1150, 1100],
        "backlog": [5000, 5250, 5300, 5500, 5650, 5800],
    }


@router.get("/court-performance")
def get_court_performance(
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.ADMIN, UserRole.REGISTRAR)),
) -> Any:
    return {
        "courts": ["District Court A", "District Court B", "Sessions Court C"],
        "clearance_rate": [78.5, 65.2, 82.1],
        "avg_disposal_days": [180, 240, 150],
        "pending_cases": [1200, 2100, 900],
    }
