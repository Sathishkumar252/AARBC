"""API V1 Router"""
from fastapi import APIRouter

from app.api.v1.auth import router as auth_router
from app.api.v1.cases import router as cases_router
from app.api.v1.alerts import router as alerts_router
from app.api.v1.analytics import router as analytics_router
from app.api.v1.documents import router as documents_router
from app.api.v1.users import router as users_router

router = APIRouter()
router.include_router(auth_router, prefix="/auth", tags=["Authentication"])
router.include_router(users_router, prefix="/users", tags=["Users"])
router.include_router(cases_router, prefix="/cases", tags=["Cases"])
router.include_router(alerts_router, prefix="/alerts", tags=["Alerts"])
router.include_router(analytics_router, prefix="/analytics", tags=["Analytics"])
router.include_router(documents_router, prefix="/documents", tags=["Documents"])
