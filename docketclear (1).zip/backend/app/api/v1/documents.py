"""Document upload and OCR endpoints"""
import os
import uuid
from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.api.v1.users import get_current_user, require_role
from app.core.config import settings
from app.db.session import get_db
from app.models.document import Document
from app.models.user import UserRole
from app.utils.ocr import extract_text_from_file

router = APIRouter()


@router.post("/upload/{case_id}")
async def upload_document(
    case_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(require_role(UserRole.CLERK, UserRole.REGISTRAR)),
) -> Any:
    ext = os.path.splitext(file.filename)[1]
    unique_name = f"{uuid.uuid4()}{ext}"
    storage_path = f"cases/{case_id}/{unique_name}"

    # In production: upload to MinIO/S3
    content = await file.read()

    doc = Document(
        case_id=case_id,
        filename=unique_name,
        original_filename=file.filename,
        file_type=ext.replace(".", ""),
        file_size=len(content),
        storage_path=storage_path,
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    # Async OCR processing (in production via Celery)
    try:
        ocr_result = extract_text_from_file(content, ext)
        doc.ocr_text = ocr_result["text"]
        doc.ocr_confidence = ocr_result["confidence"]
        db.commit()
    except Exception:
        pass

    return {"document_id": doc.id, "filename": file.filename, "ocr_status": "processing"}
